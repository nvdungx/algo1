/* *****************************************************************************
 *  Name:              Nguyen Van Dung
 *  Coursera User ID:
 *  Last modified:     August 18, 2021
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
